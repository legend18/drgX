//
//  TalkObject.m
//  FirstGame
//
//  Created by yfzx on 13-10-23.
//
//

#import "TalkObject.h"

@implementation TalkObject

@synthesize speak1; // 说话人1
@synthesize speak1FrameName; // 说话人1图片所在plist位置
@synthesize speak1PngName;   // 说话人1图片名称

@synthesize speak2; // 说话人2
@synthesize speak2FrameName; // 说话人2图片所在plist位置
@synthesize speak2PngName;   // 说话人2图片名称

@synthesize talkMsgArray; // 说话内容数组

@end
