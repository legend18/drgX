//
//  Lev.m
//  MyGame
//
//  Created by yfzx on 13-10-29.
//
//

#import "Lev.h"

@implementation Lev

@synthesize level;
@synthesize hpNow;
@synthesize totalHp;
@synthesize ATN;
@synthesize DEF;
@synthesize INT;
@synthesize nowExp;
@synthesize levExp;

@end
