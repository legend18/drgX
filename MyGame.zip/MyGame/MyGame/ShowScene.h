//
//  ShowScene.h
//  FirstGame
//
//  Created by yfzx on 13-10-29.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface ShowScene : CCLayer {
    
}

+(CCScene *)scene;

-(void)show;

-(void)createBg;

@end
