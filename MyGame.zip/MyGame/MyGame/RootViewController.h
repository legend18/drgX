//
//  RootViewController.h
//  MyGame
//
//  Created by yfzx on 13-10-29.
//  Copyright __MyCompanyName__ 2013年. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
