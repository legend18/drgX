//
//  SettingScene.h
//  MyGame
//
//  Created by yfzx on 13-11-6.
//
//
#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SettingScene : CCLayer

+(CCScene *) scene;

@end
