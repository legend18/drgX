//
//  CCMenuItemLabel2.h
//  MyGame
//
//  Created by yfzx on 13-10-31.
//
//

#import "CCMenuItem.h"

@interface CCMenuItemLabel2 : CCMenuItemLabel

@property(nonatomic,retain) NSString *skillIcon;
@property(nonatomic,retain) NSString *skillName;
@property(nonatomic,retain) NSString *skillDescription;

@end
