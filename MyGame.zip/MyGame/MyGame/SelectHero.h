//
//  SelectHero.h
//  MyGame
//
//  Created by yfzx on 13-11-5.
//  Copyright 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SelectHero : CCLayer {
    
}

+(CCScene *) scene;

-(void)createScene;

-(void)createMenu_play;

@end
